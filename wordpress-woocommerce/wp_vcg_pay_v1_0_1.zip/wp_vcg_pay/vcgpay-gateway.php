<?php
/*
 * Plugin Name: Платёжный плагин VCG-pay для WooCommerce 
 * Description: Принимайте оплату VCG у себя на сайте!
 * Author: Andrey Kolych
 * Author URI: https://guruweb.site
 * Version: 1.0.1
 *
 */
 
 
 add_filter( 'woocommerce_payment_gateways', 'vcgpay_register_gateway_class' );
 
 function vcgpay_register_gateway_class( $gateways ) {
	$gateways[] = 'WC_VCGpay_Gateway'; 
	return $gateways;
}


add_action( 'plugins_loaded', 'vcgpay_gateway_class' );

function vcgpay_gateway_class() {
	class WC_VCGpay_Gateway extends WC_Payment_Gateway {
		public function __construct() {
			
			$this->id = 'vcgpay';
			$this->icon = '';
			$this->method_title = 'Оплата VCG-pay';
			$this->method_description = 'Плагин VCG-pay для использования оплаты в woocommerce';
			
			$this->init_form_fields();
			$this->init_settings();
			$this->title = $this->settings['title'];
			$this->description = $this->settings['description'];
			$this->enabled = $this->get_option( 'enabled' );
			$this->redirect_page_id = $this->settings['returnUrl'];
			 $this->serviceUrl = $this->settings['returnUrl'];
			$this->merchant = $this->settings['merchant'];
            $this->api = $this->settings['api'];
			
            $this->signature = $this->settings['signature'];
            $this->signature2 = $this->settings['signature2'];
            $this->signature3 = $this->settings['signature3'];
			add_action('woocommerce_api_' . strtolower(get_class($this)), array($this, 'check_vcgpay_response'));
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
			add_action('woocommerce_receipt_vcgpay', array(&$this, 'receipt_page'));
		}
		public function init_form_fields(){
			$this->form_fields = array(
				'enabled' => array(
				'title'       => 'Включен/Выключен',
				'label'       => 'Включить VCG-pay плагин',
				'type'        => 'checkbox',
				'description' => '',
				'default'     => 'no'
				),
				'title' => array(
				'title'       => 'Заголовок',
				'type'        => 'text',
				'description' => 'Это то, что пользователь увидит как название метода оплаты на странице оформления заказа.',
				'default'     => 'Оплатить VCG-pay',
				'desc_tip'    => true,
				),
				'description' => array(
				'title'       => 'Описание',
				'type'        => 'textarea',
				'description' => 'Описание этого метода оплаты, которое будет отображаться пользователю на странице оформления заказа.',
				'default'     => 'Оплатите при помощи VCG-pay.',
				),
				'returnUrl' => array('title' => 'Return URL',
                    'type' => 'text',
                    'description' => 'URL of success page',
                    'default' => '',
                    'desc_tip' => true
                ),
				'merchant' => array(
				'title'       => 'ID магазина',
				'type'        => 'text'
				),
				'api' => array(
				'title'       => 'API-key',
				'type'        => 'text'
				),
				'signature' => array(
				'title'       => 'URL VCG Pay API',
				'type'        => 'text'
				),
				'signature2' => array(
				'title'       => 'URL конвертера валют',
				'type'        => 'text'
				),
				'signature3' => array(
				'title'       => 'URL модуля оплаты',
				'type'        => 'text'
				),
				'returnUrl' => array('title' => 'Return URL',
                'type' => 'select',
                'options' => $this->vcgpay_get_pages('Select Page'),
                'description' => 'URL of success page',
                'desc_tip' => true)
			);
			
		}
		
		 function receipt_page($order)
        {
            global $woocommerce;

            echo '<p>Спасибо за ваш заказ, сейчас вы будете перенаправлены на страницу оплаты WayForPay</p>';
            echo $this->generate_vcgpay_form($order);

            $woocommerce->cart->empty_cart();
        }
		
		public function generate_vcgpay_form( $order_id ) {
			 $order = new WC_Order($order_id);
			 
			
			 
			 $description = 'Order №' . $order_id;
			 $callbackURL = $this->getCallbackUrls($order_id);
			 $redirectURL = $this->getCallbackUrl(true);
			 $url_api_vcg  = $this->signature;
			 $url_conver_vcg  = $this->signature2;
			 $url_pay_vcg  = $this->signature3;
			 $idmarket = $this->merchant;
			 $apikay  = $this->api;
			 $amount = str_replace(',', '.', $order->get_total());
			 $currency_code = get_woocommerce_currency();
			 
			 
			 
			 
			$curl = curl_init();
			curl_setopt_array($curl, array(
			CURLOPT_URL => $url_conver_vcg . $currency_code .'/' . $amount .'/VCG/',
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'GET',
			CURLOPT_HTTPHEADER => array(
			'Cookie: route=24ba5ca1f54a31753eb55e1d335849ad5c9d723e'
			),
			));

		$response = curl_exec($curl);
		$total =json_decode($response, true);
		$amounts = $total["result"] ["coins"];
curl_close($curl);
		
		
$urlsend = $url_api_vcg .'shops/'. $idmarket .'/checkouts';

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $urlsend,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => '{
"orderID": "'. $order_id .'",
"amount": '. $amounts .',
"description": "'. $description .'",
"callbackURL": "'. $callbackURL .'",
"redirectURL": "'. $redirectURL .'"
}',
  CURLOPT_HTTPHEADER => array(
    'X-API-Key:' . $apikay ,
    'Content-Type: application/json',
    'Cookie: route=24ba5ca1f54a31753eb55e1d335849ad5c9d723e'
  ),
));

$response = curl_exec($curl);

curl_close($curl);


$responseifo = json_decode($response);
$idpay = $responseifo->{'checkoutID'};


$urlpay = $url_pay_vcg .  $idpay;

		$fp = fopen ("log.txt", "w"); 
			 fwrite($fp, $urlpay);
			fclose($fp); 
		 
		curl_close($curl);
			
	 return $this->fillPayForm($urlpay);
			
		}
		
		 public function fillPayForm($urlpay)
        {
			return $this->generateForm($urlpay);
		}
		
		 protected function generateForm($urlpay)
        {
           
            
            $button = '<script>
		function submitWayForPayForm()
		{
			window.location.href = "'. $urlpay .'";
		}
		setTimeout( submitWayForPayForm, 200 );
	</script>';

            return $button;
        }
		
		
		 function payment_fields()
        {
            if ($this->description) {
                echo wpautop(wptexturize($this->description));
            }
        }
		
		function process_payment($order_id)
        {
            $order = new WC_Order($order_id);

            if (version_compare(WOOCOMMERCE_VERSION, '2.1.0', '>=')) {
                /* 2.1.0 */
                $checkout_payment_url = $order->get_checkout_payment_url(true);
            } else {
                /* 2.0.0 */
                $checkout_payment_url = get_permalink(get_option('woocommerce_pay_page_id'));
            }

            return array('result' => 'success',
                'redirect' => add_query_arg('order', $order->id, add_query_arg('key', $order->order_key, $checkout_payment_url)));
        }

		
		
		private function getCallbackUrls($orderId)
        {
			
			$order = new WC_Order($orderId);
			
			 $order->update_status('processing');
             $order->payment_complete();
        }

		private function getCallbackUrl($service = false)
        {
			
			

            $redirect_url = ($this->redirect_page_id == "" || $this->redirect_page_id == 0) ? get_site_url() . "/" : get_permalink($this->redirect_page_id);
            if (!$service) {
		if (
		    isset($this->settings['returnUrl']) &&
		    trim($this->settings['returnUrl']) !== ''
	   	) {
		    return trim($this->settings['returnUrl']);
		}
                return $redirect_url;
            }

            return $redirect_url;
        }
		
		
		 // get all pages
        function vcgpay_get_pages($title = false, $indent = true)
        {
            $wp_pages = get_pages('sort_column=menu_order');
            $page_list = array();
            if ($title) {
                $page_list[] = $title;
            }
            foreach ($wp_pages as $page) {
                $prefix = '';
                // show indented child pages?
                if ($indent) {
                    $has_parent = $page->post_parent;
                    while ($has_parent) {
                        $prefix .= ' - ';
                        $next_page = get_page($has_parent);
                        $has_parent = $next_page->post_parent;
                    }
                }
                // add to page list array array
                $page_list[$page->ID] = $prefix . $page->post_title;
            }
            return $page_list;
        }
		
	}
	
	
}