<?php
// Text
$_['text_title'] = 'VCG pay';
