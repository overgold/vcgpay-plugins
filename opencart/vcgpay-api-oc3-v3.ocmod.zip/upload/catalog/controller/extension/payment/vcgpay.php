<?php
class ControllerExtensionPaymentVCGpay extends Controller {
  

    public function index() {

    $data['button_confirm'] = $this->language->get('button_confirm');
    $order_id = 'Order_'. $this->session->data['order_id'];

    $this->load->model('checkout/order');

    $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
    $code = $this->session->data['currency'];
    $version     = '1';
    $description = $this->config->get('config_name') . ', Order №' . $this->session->data['order_id'] . ', Email: ' . $order_info['email'];
    $callbackURL  = $this->url->link('extension/payment/vcgpay/callback', '', true);
    $redirectURL  = $this->url->link('extension/payment/vcgpay/result', '', true);
    $url_api_vcg = $this->config->get('payment_vcgpay_signature');
    $url_conver_vcg = $this->config->get('payment_vcgpay_signature2');
    $url_pay_vcg = $this->config->get('payment_vcgpay_signature3');
    $idmarket  = $this->config->get('payment_vcgpay_merchant');
    $apikay      = $this->config->get('payment_vcgpay_api');
       
    


    $curl = curl_init();



curl_setopt_array($curl, array(
  CURLOPT_URL => $url_conver_vcg . $code .'/' . $order_info['total'] .'/VCG/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Cookie: route=24ba5ca1f54a31753eb55e1d335849ad5c9d723e'
  ),
));

$response = curl_exec($curl);
$total =json_decode($response, true);
$amount = $total["result"] ["coins"];
curl_close($curl);

$urlsend = $url_api_vcg .'shops/'. $idmarket .'/checkouts';
  


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $urlsend,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => '{
"orderID": "'. $order_id .'",
"amount": '. $amount .',
"description": "'. $description .'",
"callbackURL": "'. $callbackURL .'",
"redirectURL": "'. $redirectURL .'"
}',
  CURLOPT_HTTPHEADER => array(
    'X-API-Key:' . $apikay ,
    'Content-Type: application/json',
    'Cookie: route=24ba5ca1f54a31753eb55e1d335849ad5c9d723e'
  ),
));

$response = curl_exec($curl);

curl_close($curl);


$responseifo = json_decode($response);
$idpay = $responseifo->{'checkoutID'};


$urlpay = $url_pay_vcg .  $idpay;


  $data['action']    = $urlpay;
   
    
   return $this->load->view('extension/payment/vcgpay', $data);
  }




  public function callback() {
    
    $this->load->model('checkout/order');

$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order ORDER BY order_id DESC LIMIT 1");
$order_id = $query->rows[0]['order_id']; 

    
  $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_vcgpay_order_status_id'));
    
  
  }

  public function result() {
    
    $this->load->model('checkout/order');
    
   

     
        $this->response->redirect($this->url->link('checkout/success', '', true));
     
    
  
  }
	
}
